const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

async function createAdmin() {
  const pool = new Pool({
    connectionString: 'postgresql://postgres@localhost:5432/db_dashboard'
  });
  
  const email = 'admin@localhost.com';
  const password = 'admin123456'; // Change this after first login
  const hash = await bcrypt.hash(password, 10);
  
  try {
    await pool.query(
      'INSERT INTO users (email, password_hash, role) VALUES ($1, $2, $3)',
      [email, hash, 'ADMIN']
    );
    
    console.log('✅ Admin user created successfully!');
    console.log('   Email: admin@localhost.com');
    console.log('   Password: admin123456');
    console.log('   ⚠️  CHANGE PASSWORD AFTER FIRST LOGIN!');
  } catch (error) {
    if (error.message.includes('duplicate key')) {
      console.log('ℹ️  Admin user already exists');
    } else {
      console.error('Error:', error.message);
    }
  }
  
  await pool.end();
}

createAdmin();