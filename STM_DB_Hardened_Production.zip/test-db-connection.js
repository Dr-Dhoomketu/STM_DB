const { Pool } = require('pg');

async function testConnection() {
  console.log('Testing database connection...');
  
  const pool = new Pool({
    connectionString: 'postgresql://dbadmin:dbadmin123@localhost:5432/db_dashboard'
  });
  
  try {
    const result = await pool.query('SELECT id, email, role FROM users LIMIT 1');
    console.log('✅ Database connection successful!');
    console.log('User found:', result.rows[0]);
    
    // Test bcrypt
    const bcrypt = require('bcryptjs');
    const user = result.rows[0];
    const testPassword = 'admin123456';
    
    const hashResult = await pool.query('SELECT password_hash FROM users WHERE email = $1', [user.email]);
    const storedHash = hashResult.rows[0].password_hash;
    
    const isValid = await bcrypt.compare(testPassword, storedHash);
    console.log('✅ Password verification:', isValid);
    
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
  } finally {
    await pool.end();
  }
}

testConnection();